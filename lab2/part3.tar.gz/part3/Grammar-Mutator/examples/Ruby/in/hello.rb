print "Hello, World!\n"

