TODO
===

- Incorporate AFL-style mutations into the grammar mutator for havoc stage
- Add regex support for specifying grammar rules
