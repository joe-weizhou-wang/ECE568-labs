xxHash
===

Github repo: https://github.com/Cyan4973/xxHash/tree/v0.8.0
